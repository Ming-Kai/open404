@package.line@class @domain.prefix@UserRoleRel {
    @domain.prefix@User user
    @domain.prefix@Role role
}
