#*Grails Audit Logging Plugin*#

The Audit Logging plugin can add Hibernate Events based Audit Logging to a Grails project and it can also add support to domain models for hooking into the hibernate events system.

##**Documentation**##
For documentation, see [Grails Plugin Page](http://grails.org/plugin/audit-logging "Grails Plugin Page")

##**Issue Management**##
See [JIRA](http://jira.grails.org/browse/GPAUDITLOGGING "GPAUDITLOGGING JIRA")

