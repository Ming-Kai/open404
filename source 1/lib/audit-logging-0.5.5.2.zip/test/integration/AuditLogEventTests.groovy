class AuditLogEventTests extends GroovyTestCase {
  /**
   * Sadly, in order to see the plugin work, you must
   * set up a project with domain classes. I have built
   * several test projects with different domains for this
   * job but have no idea how you would put them in
   * the SVN repository for testing this plugin.
   */

    void testSomething() {

    }
}
